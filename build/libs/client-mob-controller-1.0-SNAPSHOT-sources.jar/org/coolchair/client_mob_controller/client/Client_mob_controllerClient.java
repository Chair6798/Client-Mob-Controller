package org.coolchair.client_mob_controller.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.network.chat.Component;
public class Client_mob_controllerClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommands.literal("myclientcommand")
                    .executes(context -> {
                        context.getSource().sendFeedback(Component.literal("Hello from client!"));
                        return 1;
                    })
            );
        });
    }
}
